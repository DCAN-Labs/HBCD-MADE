Getting the HBCD-MADE Container
-------------------------------

The container for HBCD-MADE can be found on Docker Hub. It can be downloaded with singularity as follows:

.. code-block:: console

   singularity pull hbcd_made_latest.sif docker://dcanumn/hbcd-made:1.0.9